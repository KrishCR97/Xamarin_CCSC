package com.example.s528749.formwithlistxamarin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static ArrayList<String> items = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addItem(View v){
        TextView inputTV =  (TextView) findViewById(R.id.inputItem);

        if (inputTV.getText().toString().isEmpty()) {
            inputTV.setError("Please enter a valid item name");
        } else {
            String itemName = inputTV.getText().toString();
            items.add(itemName);
            Intent displayItems = new Intent(this,  ItemList.class);
            displayItems.putStringArrayListExtra("item",items);
            startActivity(displayItems);
        }




    }
}
