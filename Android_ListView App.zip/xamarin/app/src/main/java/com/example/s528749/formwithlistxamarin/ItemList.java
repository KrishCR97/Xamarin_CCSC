package com.example.s528749.formwithlistxamarin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ItemList extends AppCompatActivity {

    public ArrayList<String> itemName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list);

        Intent display = getIntent();
     itemName = display.getStringArrayListExtra("item");
        populateListView();
    }
    public void populateListView(){
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.itemtextview,itemName);
        ListView list = (ListView) findViewById(R.id.ItemsList);
        list.setAdapter(adapter);

    }
}
